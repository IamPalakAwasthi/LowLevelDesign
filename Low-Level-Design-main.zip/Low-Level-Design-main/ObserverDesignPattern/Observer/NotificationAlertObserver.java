package BehaviouralDesignPatterns.ObserverDesignPattern.Observer;

public interface NotificationAlertObserver {
    public void update();

}
