package BehaviouralDesignPatterns.IteratorDesignPattern;

public interface Aggregator {
    Iterator createIterator();
}
