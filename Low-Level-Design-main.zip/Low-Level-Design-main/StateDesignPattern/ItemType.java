package BehaviouralDesignPatterns.StateDesignPattern;

public enum ItemType {

    COKE,
    PEPSI,
    JUICE,
    SODA;
}

