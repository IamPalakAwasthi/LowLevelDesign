package BehaviouralDesignPatterns.StrategyDesignPattern.WithStrategyPattern.Strategy;

public interface DriveStrategyInterface {
    public void drive();


}
