package BehaviouralDesignPatterns.StrategyDesignPattern.WithoutStrategyPattern;

public class PassengerVehicle extends Vehicle{
}
