package CreationalDesignPattern.FactoryPattern.AbstractFactoryPattern.Dough;

public interface Dough {

    String toString();

}
