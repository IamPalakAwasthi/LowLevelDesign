package CreationalDesignPattern.FactoryPattern.AbstractFactoryPattern.Pepperoni;

public interface Pepperoni {
    String toString();
}
