package CreationalDesignPattern.FactoryPattern.AbstractFactoryPattern.Sauce;

public interface Sauce {
    String toString();
}
