package CreationalDesignPattern.FactoryPattern.AbstractFactoryPattern.Cheese;

public interface Cheese {
    String toString();
}
