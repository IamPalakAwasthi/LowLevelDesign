package CreationalDesignPattern.FactoryPattern.AbstractFactoryPattern;

public class main {
}
