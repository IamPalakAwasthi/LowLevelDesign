package BehaviouralDesignPatterns.CommandDesignPattern;

public class Main {
}
